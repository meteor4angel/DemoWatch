﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace TestApi.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private static List<Product> products = new List<Product>
        {
            new Product { Id = 1, Name = "Product1", Description = "Description1", Price = 100 },
            new Product { Id = 2, Name = "Product2", Description = "Description2", Price = 200 },
        };

        // GET: api/products
        [HttpGet]
        public IActionResult GetAllProducts([FromQuery] string nameFilter = null)
        {
            try
            {
                var filteredProducts = string.IsNullOrWhiteSpace(nameFilter)
                    ? products
                    : products.Where(p => p.Name.Contains(nameFilter)).ToList();

                if (!filteredProducts.Any())
                {
                    return NotFound("No products found matching the criteria.");
                }

                return Ok(filteredProducts);
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }

        // GET: api/products/1
        [HttpGet("{id}")]
        public IActionResult GetProductById(int id)
        {
            try
            {
                var product = products.FirstOrDefault(p => p.Id == id);
                if (product == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }
                return Ok(product);
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }

        // POST: api/products
        [HttpPost]
        public IActionResult CreateProduct([FromBody] ProductRequest productRequest)
        {
            if (productRequest == null || string.IsNullOrEmpty(productRequest.Name))
            {
                return BadRequest("Product data is invalid.");
            }

            try
            {
                var newProduct = new Product
                {
                    Id = products.Max(p => p.Id) + 1,
                    Name = productRequest.Name,
                    Description = productRequest.Description,
                    Price = productRequest.Price
                };

                products.Add(newProduct);
                return CreatedAtAction(nameof(GetProductById), new { id = newProduct.Id }, newProduct);
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }

        // PUT: api/products/1
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, [FromBody] ProductRequest productRequest)
        {
            if (productRequest == null || string.IsNullOrEmpty(productRequest.Name))
            {
                return BadRequest("Product data is invalid.");
            }

            try
            {
                var product = products.FirstOrDefault(p => p.Id == id);
                if (product == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }

                product.Name = productRequest.Name;
                product.Description = productRequest.Description;
                product.Price = productRequest.Price;

                return NoContent(); // 204 No Content for successful update with no content to return
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }

        // DELETE: api/products/1
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                var product = products.FirstOrDefault(p => p.Id == id);
                if (product == null)
                {
                    return NotFound($"Product with ID {id} not found.");
                }

                products.Remove(product);
                return NoContent(); // 204 No Content for successful deletion with no content to return
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }

        // DELETE: api/products
        [HttpDelete]
        public IActionResult DeleteAllProducts([FromQuery] bool confirm = false)
        {
            if (!confirm)
            {
                return BadRequest("Confirmation required to delete all products.");
            }

            try
            {
                products.Clear();
                return NoContent(); // 204 No Content for successful deletion with no content to return
            }
            catch
            {
                return StatusCode(500, "Internal server error.");
            }
        }
    }

    // Models
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
    }

    public class ProductRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
    }
    

}
