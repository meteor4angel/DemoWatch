﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class PowerPointProcessor
{
    private readonly List<string> _wordsToRemove;

    public PowerPointProcessor(List<string> wordsToRemove)
    {
        _wordsToRemove = wordsToRemove;
    }

    public void ProcessPresentation(string inputPath, string outputPath)
    {
        // Copy the original file to the output path
        File.Copy(inputPath, outputPath, true);

        using (PresentationDocument presentationDoc = PresentationDocument.Open(outputPath, true))
        {
            PresentationPart presentationPart = presentationDoc.PresentationPart;
            if (presentationPart != null)
            {
                foreach (var slidePart in presentationPart.SlideParts)
                {
                    RemoveWordsFromSlide(slidePart);
                }
            }
        }
    }

    private void RemoveWordsFromSlide(SlidePart slidePart)
    {
        foreach (var text in slidePart.Slide.Descendants<DocumentFormat.OpenXml.Drawing.Text>())
        {
            string originalText = text.Text;
            foreach (var word in _wordsToRemove)
            {
                originalText = originalText.Replace(word, "", StringComparison.OrdinalIgnoreCase);
            }
            text.Text = originalText;
        }
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        string inputFilePath = "C:\\Users\\Joyce\\Downloads\\PII-Identifying and Managing Risk1.pptx";
        string outputFilePath = "C:\\Users\\Joyce\\Downloads\\path_to_output_presentation.pptx";
        List<string> wordsToRemove = new List<string> { "word1", "word2", "word3", "PII" };

        PowerPointProcessor processor = new PowerPointProcessor(wordsToRemove);
        processor.ProcessPresentation(inputFilePath, outputFilePath);

        Console.WriteLine("Processing completed. The output file is saved at: " + outputFilePath);
    }
}