﻿using System;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using static System.Net.Mime.MediaTypeNames;

public class WordProcessor
{
    public void FindAndRemoveString(string inputFilePath, string outputFilePath, string stringToRemove)
    {
        // Copy the input file to the output path if the paths are different
        if (inputFilePath != outputFilePath)
        {
            File.Copy(inputFilePath, outputFilePath, true);
        }

        // Open the Word document
        using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(outputFilePath, true))
        {
            // Get the main document part
            MainDocumentPart mainPart = wordDoc.MainDocumentPart;

            // Iterate through all paragraphs in the document
            foreach (var text in mainPart.Document.Descendants<DocumentFormat.OpenXml.Wordprocessing.Text>())
            {
                if (text.Text.Contains(stringToRemove))
                {
                    text.Text = text.Text.Replace(stringToRemove, string.Empty);
                }
            }

            // Save changes to the document
            mainPart.Document.Save();
        }
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        //if (args.Length < 3)
        //{
        //    Console.WriteLine("Usage: Program <inputFilePath> <outputFilePath> <stringToRemove>");
        //    return;
        //}

        string inputFilePath = "C:\\Users\\Joyce\\Downloads\\example03.docx";//args[0];
        string outputFilePath = "C:\\Users\\Joyce\\Downloads\\word.docx";// args[1];
        string stringToRemove = "heading";// args[2];

        WordProcessor processor = new WordProcessor();
        processor.FindAndRemoveString(inputFilePath, outputFilePath, stringToRemove);

        Console.WriteLine("String removed and Word document saved successfully.");
    }
}