﻿using System;
using System.IO;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

public class ExcelProcessor
{
    public void FindAndRemovePattern(string inputPath, string outputPath, string pattern)
    {
        // Copy the input file to the output path if the paths are different
        if (inputPath != outputPath)
        {
            File.Copy(inputPath, outputPath, true);
        }

        // Open the Excel file
        using (SpreadsheetDocument document = SpreadsheetDocument.Open(outputPath, true))
        {
            WorkbookPart workbookPart = document.WorkbookPart;

            foreach (Sheet sheet in workbookPart.Workbook.Sheets)
            {
                WorksheetPart worksheetPart = (WorksheetPart)workbookPart.GetPartById(sheet.Id);
                SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();

                foreach (Row row in sheetData.Elements<Row>())
                {
                    foreach (Cell cell in row.Elements<Cell>())
                    {
                        // Get the cell value
                        string cellValue = GetCellValue(workbookPart, cell);

                        // Check and remove content matching the regex pattern from the cell's content
                        if (!string.IsNullOrEmpty(cellValue))
                        {
                            var regex = new Regex(pattern, RegexOptions.IgnoreCase);
                            if (regex.IsMatch(cellValue))
                            {
                                cellValue = regex.Replace(cellValue, string.Empty);

                                // Update the cell with the new value
                                cell.CellValue = new CellValue(cellValue);
                                cell.DataType = new EnumValue<CellValues>(CellValues.String);
                            }
                        }
                    }
                }

                // Save changes to the worksheet
                worksheetPart.Worksheet.Save();
            }
        }
    }

    private string GetCellValue(WorkbookPart workbookPart, Cell cell)
    {
        if (cell == null || cell.CellValue == null)
            return string.Empty;

        string value = cell.CellValue.InnerText;

        if (cell.DataType is not null)
        {
            if (cell.DataType.Value == CellValues.SharedString)
            {
                var stringTable = workbookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault();
                if (stringTable is not null)
                {
                    return stringTable.SharedStringTable.ElementAt(int.Parse(value)).InnerText;
                }

                return "";
            }
            else if(cell.DataType.Value == CellValues.Boolean)
            {
                return value == "1" ? "TRUE" : "FALSE";
            }
            else
            { return value; }
        }

        //if (cell.DataType != null)
        //{

        //    switch (cell.DataType.Value.ToString())
        //    {
        //        case sharedString:
        //            if (int.TryParse(value, out int index))
        //            {
        //                SharedStringItem ssi = workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(index);
        //                return ssi.Text?.Text ?? ssi.InnerText;
        //            }
        //            break;
        //        case boolean:
        //            return value == "1" ? "TRUE" : "FALSE";
        //        default:
        //            return value;
        //    }
        //}
        return value;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        string inputFilePath = "C:\\Users\\Joyce\\Downloads\\excel_exercise5.xlsx";
        string outputFilePath = "C:\\Users\\Joyce\\Downloads\\path_to_output_excel.xlsx";
        string pattern = @"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"; // Regex pattern for email addresses

        ExcelProcessor processor = new ExcelProcessor();
        processor.FindAndRemovePattern(inputFilePath, outputFilePath, pattern);

        Console.WriteLine("Content matching the specified pattern removed and Excel file saved successfully.");
    }
}