﻿using System;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp.Drawing;

public class PdfProcessor
{
    public void FindAndRemoveString(string inputFilePath, string outputFilePath, string stringToRemove)
    {
        // Open the PDF document
        PdfDocument document = PdfReader.Open(inputFilePath, PdfDocumentOpenMode.Modify);

        foreach (PdfPage page in document.Pages)
        {
            // Extract text from the page
            string pageContent = ExtractTextFromPage(page);

            if (pageContent.Contains(stringToRemove))
            {
                string modifiedContent = pageContent.Replace(stringToRemove, string.Empty);

                // Clear the content of the page
                XGraphics gfx = XGraphics.FromPdfPage(page);
                //gfx.Clear(XColors.White);

                // Add the modified content back to the page
                gfx.DrawString(modifiedContent, new XFont("Arial", 12), XBrushes.Black, new XRect(0, 0, page.Width, page.Height), XStringFormats.TopLeft);
            }
        }

        // Save the modified document
        document.Save(outputFilePath);
    }

    private string ExtractTextFromPage(PdfPage page)
    {
        // This is a placeholder for text extraction logic
        // PdfSharp does not provide text extraction out of the box
        // You may need to use another library like PDFBox or iText7 for text extraction
        return string.Empty;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        // Uncomment the following lines to use command-line arguments
        // if (args.Length < 3)
        // {
        //     Console.WriteLine("Usage: Program <inputFilePath> <outputFilePath> <stringToRemove>");
        //     return;
        // }

        string inputFilePath = "C:\\Users\\Joyce\\Downloads\\example.pdf"; // args[0];
        string outputFilePath = "C:\\Users\\Joyce\\Downloads\\output.pdf"; // args[1];
        string stringToRemove = "Example"; // args[2];

        PdfProcessor processor = new PdfProcessor();
        processor.FindAndRemoveString(inputFilePath, outputFilePath, stringToRemove);

        Console.WriteLine("String removed and PDF document saved successfully.");
    }
}